﻿namespace PBL_3
{
    partial class BookManagementForm
    {
        private const string V = "BookManagementForm";

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            this.IDcategoryerror = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Button5 = new Guna.UI2.WinForms.Guna2Button();
            this.searchTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.listSearchCb = new Guna.UI2.WinForms.Guna2ComboBox();
            this.mainPanel = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.deletePanel = new Guna.UI2.WinForms.Guna2Panel();
            this.deleteDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            this.guna2Panel3 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel11 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.deleteBarBtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.addPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.bookYearError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bookCategoryError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bookAuthorError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.quantityError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bookTiltleError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.cbbCategory = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.panelLb = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.saveBookBtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.yearTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.authorTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.quantityTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.titleTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.addcategorypanel = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Panel4 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2HtmlLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.categoryLocationError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.SaveCategoryBtn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.categoryDayError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.categoryNumberdayTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.categoryNameError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.categoryLocationTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.categoryNameTxt = new Guna.UI2.WinForms.Guna2TextBox();
            this.addCategory = new Guna.UI2.WinForms.Guna2Button();
            this.addBtn = new Guna.UI2.WinForms.Guna2Button();
            this.catalogPanel = new Guna.UI2.WinForms.Guna2Panel();
            this.catalogDGV = new Guna.UI2.WinForms.Guna2DataGridView();
            this.updateBtn = new Guna.UI2.WinForms.Guna2Button();
            this.deleteBtn = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel13 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.authorError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.tiltleError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.yearError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.namecategoryerror = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.locationerror = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.idError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.categoryError = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.numberdayerror = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.mainPanel.SuspendLayout();
            this.deletePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deleteDGV)).BeginInit();
            this.guna2Panel3.SuspendLayout();
            this.addPanel.SuspendLayout();
            this.guna2Panel1.SuspendLayout();
            this.addcategorypanel.SuspendLayout();
            this.guna2Panel4.SuspendLayout();
            this.catalogPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.catalogDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // IDcategoryerror
            // 
            this.IDcategoryerror.BackColor = System.Drawing.Color.Transparent;
            this.IDcategoryerror.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IDcategoryerror.ForeColor = System.Drawing.Color.Red;
            this.IDcategoryerror.Location = new System.Drawing.Point(176, 298);
            this.IDcategoryerror.Name = "IDcategoryerror";
            this.IDcategoryerror.Size = new System.Drawing.Size(123, 15);
            this.IDcategoryerror.TabIndex = 4;
            this.IDcategoryerror.Text = "Please fill this information!";
            this.IDcategoryerror.Visible = false;
            // 
            // guna2HtmlLabel6
            // 
            this.guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel6.ForeColor = System.Drawing.Color.Red;
            this.guna2HtmlLabel6.Location = new System.Drawing.Point(173, 456);
            this.guna2HtmlLabel6.Name = "guna2HtmlLabel6";
            this.guna2HtmlLabel6.Size = new System.Drawing.Size(123, 15);
            this.guna2HtmlLabel6.TabIndex = 1;
            this.guna2HtmlLabel6.Text = "Please fill this information!";
            this.guna2HtmlLabel6.Visible = false;
            // 
            // guna2HtmlLabel7
            // 
            this.guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel7.ForeColor = System.Drawing.Color.Red;
            this.guna2HtmlLabel7.Location = new System.Drawing.Point(173, 533);
            this.guna2HtmlLabel7.Name = "guna2HtmlLabel7";
            this.guna2HtmlLabel7.Size = new System.Drawing.Size(123, 15);
            this.guna2HtmlLabel7.TabIndex = 1;
            this.guna2HtmlLabel7.Text = "Please fill this information!";
            this.guna2HtmlLabel7.Visible = false;
            // 
            // guna2HtmlLabel5
            // 
            this.guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel5.ForeColor = System.Drawing.Color.Red;
            this.guna2HtmlLabel5.Location = new System.Drawing.Point(173, 302);
            this.guna2HtmlLabel5.Name = "guna2HtmlLabel5";
            this.guna2HtmlLabel5.Size = new System.Drawing.Size(123, 15);
            this.guna2HtmlLabel5.TabIndex = 1;
            this.guna2HtmlLabel5.Text = "Please fill this information!";
            this.guna2HtmlLabel5.Visible = false;
            // 
            // guna2HtmlLabel8
            // 
            this.guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel8.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel8.ForeColor = System.Drawing.Color.Red;
            this.guna2HtmlLabel8.Location = new System.Drawing.Point(173, 379);
            this.guna2HtmlLabel8.Name = "guna2HtmlLabel8";
            this.guna2HtmlLabel8.Size = new System.Drawing.Size(123, 15);
            this.guna2HtmlLabel8.TabIndex = 1;
            this.guna2HtmlLabel8.Text = "Please fill this information!";
            this.guna2HtmlLabel8.Visible = false;
            // 
            // guna2Button5
            // 
            this.guna2Button5.BorderRadius = 10;
            this.guna2Button5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button5.FillColor = System.Drawing.Color.Transparent;
            this.guna2Button5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button5.ForeColor = System.Drawing.Color.White;
            this.guna2Button5.ImageOffset = new System.Drawing.Point(0, -2);
            this.guna2Button5.ImageSize = new System.Drawing.Size(23, 20);
            this.guna2Button5.Location = new System.Drawing.Point(70, 555);
            this.guna2Button5.Margin = new System.Windows.Forms.Padding(4);
            this.guna2Button5.Name = "guna2Button5";
            this.guna2Button5.Size = new System.Drawing.Size(57, 53);
            this.guna2Button5.TabIndex = 7;
            // 
            // searchTxt
            // 
            this.searchTxt.BackColor = System.Drawing.Color.Transparent;
            this.searchTxt.BorderRadius = 15;
            this.searchTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.searchTxt.DefaultText = "";
            this.searchTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.searchTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.searchTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.searchTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.searchTxt.Enabled = false;
            this.searchTxt.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.searchTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.searchTxt.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.searchTxt.Location = new System.Drawing.Point(414, 10);
            this.searchTxt.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.searchTxt.Name = "searchTxt";
            this.searchTxt.PasswordChar = '\0';
            this.searchTxt.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.searchTxt.PlaceholderText = "Search...";
            this.searchTxt.SelectedText = "";
            this.searchTxt.Size = new System.Drawing.Size(616, 45);
            this.searchTxt.TabIndex = 21;
            this.searchTxt.TabStop = false;
            this.searchTxt.TextOffset = new System.Drawing.Point(5, 0);
            this.searchTxt.TextChanged += new System.EventHandler(this.searchTxt_TextChanged);
            this.searchTxt.Click += new System.EventHandler(this.searchTxt_Click);
            // 
            // listSearchCb
            // 
            this.listSearchCb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.listSearchCb.BorderRadius = 10;
            this.listSearchCb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.listSearchCb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.listSearchCb.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.listSearchCb.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.listSearchCb.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.listSearchCb.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.listSearchCb.ForeColor = System.Drawing.Color.Gray;
            this.listSearchCb.ItemHeight = 30;
            this.listSearchCb.Location = new System.Drawing.Point(840, 13);
            this.listSearchCb.Name = "listSearchCb";
            this.listSearchCb.Size = new System.Drawing.Size(178, 36);
            this.listSearchCb.TabIndex = 22;
            this.listSearchCb.SelectedIndexChanged += new System.EventHandler(this.listSearchCb_SelectedIndexChanged);
            this.listSearchCb.Click += new System.EventHandler(this.listSearchCb_Click);
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.Color.Transparent;
            this.mainPanel.BorderRadius = 30;
            this.mainPanel.Controls.Add(this.deletePanel);
            this.mainPanel.Controls.Add(this.listSearchCb);
            this.mainPanel.Controls.Add(this.searchTxt);
            this.mainPanel.Controls.Add(this.addPanel);
            this.mainPanel.Controls.Add(this.addcategorypanel);
            this.mainPanel.Controls.Add(this.addCategory);
            this.mainPanel.Controls.Add(this.addBtn);
            this.mainPanel.Controls.Add(this.catalogPanel);
            this.mainPanel.Controls.Add(this.guna2Button5);
            this.mainPanel.Controls.Add(this.guna2HtmlLabel2);
            this.mainPanel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(28)))), ((int)(((byte)(29)))));
            this.mainPanel.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(28)))), ((int)(((byte)(29)))));
            this.mainPanel.FillColor3 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(28)))), ((int)(((byte)(29)))));
            this.mainPanel.FillColor4 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(28)))), ((int)(((byte)(29)))));
            this.mainPanel.Location = new System.Drawing.Point(0, 0);
            this.mainPanel.Margin = new System.Windows.Forms.Padding(4);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(3112, 710);
            this.mainPanel.TabIndex = 0;
            // 
            // deletePanel
            // 
            this.deletePanel.BackColor = System.Drawing.Color.Transparent;
            this.deletePanel.BorderColor = System.Drawing.Color.White;
            this.deletePanel.BorderRadius = 25;
            this.deletePanel.Controls.Add(this.deleteDGV);
            this.deletePanel.Controls.Add(this.guna2Panel3);
            this.deletePanel.Controls.Add(this.deleteBarBtn);
            this.deletePanel.FillColor = System.Drawing.Color.White;
            this.deletePanel.Location = new System.Drawing.Point(1248, 3);
            this.deletePanel.Margin = new System.Windows.Forms.Padding(4);
            this.deletePanel.Name = "deletePanel";
            this.deletePanel.Size = new System.Drawing.Size(314, 698);
            this.deletePanel.TabIndex = 20;
            this.deletePanel.Visible = false;
            // 
            // deleteDGV
            // 
            this.deleteDGV.AllowUserToResizeColumns = false;
            this.deleteDGV.AllowUserToResizeRows = false;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle41.BackColor = System.Drawing.SystemColors.GrayText;
            dataGridViewCellStyle41.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.deleteDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle41;
            this.deleteDGV.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            this.deleteDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(88)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle42.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(88)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.deleteDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.deleteDGV.ColumnHeadersHeight = 40;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle43.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle43.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle43.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.deleteDGV.DefaultCellStyle = dataGridViewCellStyle43;
            this.deleteDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.deleteDGV.Location = new System.Drawing.Point(9, 200);
            this.deleteDGV.Name = "deleteDGV";
            this.deleteDGV.ReadOnly = true;
            this.deleteDGV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle44.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle44.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.deleteDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle44;
            this.deleteDGV.RowHeadersVisible = false;
            this.deleteDGV.RowHeadersWidth = 51;
            this.deleteDGV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle45.BackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle45.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle45.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            dataGridViewCellStyle45.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle45.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.deleteDGV.RowsDefaultCellStyle = dataGridViewCellStyle45;
            this.deleteDGV.RowTemplate.Height = 30;
            this.deleteDGV.Size = new System.Drawing.Size(295, 425);
            this.deleteDGV.TabIndex = 25;
            this.deleteDGV.TabStop = false;
            this.deleteDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.Transparent;
            this.deleteDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.deleteDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.deleteDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.deleteDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.deleteDGV.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            this.deleteDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.deleteDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            this.deleteDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.deleteDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Gainsboro;
            this.deleteDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.deleteDGV.ThemeStyle.HeaderStyle.Height = 40;
            this.deleteDGV.ThemeStyle.ReadOnly = true;
            this.deleteDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            this.deleteDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.deleteDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Gainsboro;
            this.deleteDGV.ThemeStyle.RowsStyle.Height = 30;
            this.deleteDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.deleteDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            // 
            // guna2Panel3
            // 
            this.guna2Panel3.BorderRadius = 25;
            this.guna2Panel3.Controls.Add(this.guna2HtmlLabel11);
            this.guna2Panel3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(55)))));
            this.guna2Panel3.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel3.Name = "guna2Panel3";
            this.guna2Panel3.Size = new System.Drawing.Size(314, 186);
            this.guna2Panel3.TabIndex = 3;
            // 
            // guna2HtmlLabel11
            // 
            this.guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel11.Font = new System.Drawing.Font("Segoe Script", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(72)))), ((int)(((byte)(153)))));
            this.guna2HtmlLabel11.Location = new System.Drawing.Point(22, 55);
            this.guna2HtmlLabel11.Margin = new System.Windows.Forms.Padding(4);
            this.guna2HtmlLabel11.Name = "guna2HtmlLabel11";
            this.guna2HtmlLabel11.Size = new System.Drawing.Size(272, 73);
            this.guna2HtmlLabel11.TabIndex = 18;
            this.guna2HtmlLabel11.Text = "Delete Book";
            this.guna2HtmlLabel11.TextAlignment = System.Drawing.ContentAlignment.TopCenter;
            // 
            // deleteBarBtn
            // 
            this.deleteBarBtn.BorderRadius = 20;
            this.deleteBarBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.deleteBarBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.deleteBarBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.deleteBarBtn.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.deleteBarBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.deleteBarBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(55)))));
            this.deleteBarBtn.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(55)))));
            this.deleteBarBtn.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBarBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(72)))), ((int)(((byte)(153)))));
            this.deleteBarBtn.Location = new System.Drawing.Point(39, 645);
            this.deleteBarBtn.Name = "deleteBarBtn";
            this.deleteBarBtn.Size = new System.Drawing.Size(240, 45);
            this.deleteBarBtn.TabIndex = 2;
            this.deleteBarBtn.Text = "Delete";
            this.deleteBarBtn.Click += new System.EventHandler(this.deleteBarBtn_Click);
            // 
            // addPanel
            // 
            this.addPanel.BackColor = System.Drawing.Color.Transparent;
            this.addPanel.BorderColor = System.Drawing.Color.White;
            this.addPanel.BorderRadius = 25;
            this.addPanel.Controls.Add(this.bookYearError);
            this.addPanel.Controls.Add(this.bookCategoryError);
            this.addPanel.Controls.Add(this.bookAuthorError);
            this.addPanel.Controls.Add(this.quantityError);
            this.addPanel.Controls.Add(this.bookTiltleError);
            this.addPanel.Controls.Add(this.label1);
            this.addPanel.Controls.Add(this.cbbCategory);
            this.addPanel.Controls.Add(this.guna2Panel1);
            this.addPanel.Controls.Add(this.saveBookBtn);
            this.addPanel.Controls.Add(this.yearTxt);
            this.addPanel.Controls.Add(this.authorTxt);
            this.addPanel.Controls.Add(this.quantityTxt);
            this.addPanel.Controls.Add(this.titleTxt);
            this.addPanel.FillColor = System.Drawing.Color.White;
            this.addPanel.Location = new System.Drawing.Point(1245, 4);
            this.addPanel.Margin = new System.Windows.Forms.Padding(4);
            this.addPanel.Name = "addPanel";
            this.addPanel.Size = new System.Drawing.Size(314, 698);
            this.addPanel.TabIndex = 19;
            this.addPanel.Visible = false;
            // 
            // bookYearError
            // 
            this.bookYearError.BackColor = System.Drawing.Color.Transparent;
            this.bookYearError.ForeColor = System.Drawing.Color.Red;
            this.bookYearError.Location = new System.Drawing.Point(180, 606);
            this.bookYearError.Name = "bookYearError";
            this.bookYearError.Size = new System.Drawing.Size(91, 18);
            this.bookYearError.TabIndex = 9;
            this.bookYearError.Text = "Fill information!";
            this.bookYearError.Visible = false;
            // 
            // bookCategoryError
            // 
            this.bookCategoryError.BackColor = System.Drawing.Color.Transparent;
            this.bookCategoryError.ForeColor = System.Drawing.Color.Red;
            this.bookCategoryError.Location = new System.Drawing.Point(180, 542);
            this.bookCategoryError.Name = "bookCategoryError";
            this.bookCategoryError.Size = new System.Drawing.Size(91, 18);
            this.bookCategoryError.TabIndex = 8;
            this.bookCategoryError.Text = "Fill information!";
            this.bookCategoryError.Visible = false;
            // 
            // bookAuthorError
            // 
            this.bookAuthorError.BackColor = System.Drawing.Color.Transparent;
            this.bookAuthorError.ForeColor = System.Drawing.Color.Red;
            this.bookAuthorError.Location = new System.Drawing.Point(180, 452);
            this.bookAuthorError.Name = "bookAuthorError";
            this.bookAuthorError.Size = new System.Drawing.Size(91, 18);
            this.bookAuthorError.TabIndex = 7;
            this.bookAuthorError.Text = "Fill information!";
            this.bookAuthorError.Visible = false;
            // 
            // quantityError
            // 
            this.quantityError.BackColor = System.Drawing.Color.Transparent;
            this.quantityError.ForeColor = System.Drawing.Color.Red;
            this.quantityError.Location = new System.Drawing.Point(180, 301);
            this.quantityError.Name = "quantityError";
            this.quantityError.Size = new System.Drawing.Size(91, 18);
            this.quantityError.TabIndex = 6;
            this.quantityError.Text = "Fill information!";
            this.quantityError.Visible = false;
            // 
            // bookTiltleError
            // 
            this.bookTiltleError.BackColor = System.Drawing.Color.Transparent;
            this.bookTiltleError.ForeColor = System.Drawing.Color.Red;
            this.bookTiltleError.Location = new System.Drawing.Point(180, 375);
            this.bookTiltleError.Name = "bookTiltleError";
            this.bookTiltleError.Size = new System.Drawing.Size(91, 18);
            this.bookTiltleError.TabIndex = 6;
            this.bookTiltleError.Text = "Fill information!";
            this.bookTiltleError.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            this.label1.Location = new System.Drawing.Point(20, 470);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "Category";
            // 
            // cbbCategory
            // 
            this.cbbCategory.BackColor = System.Drawing.Color.Transparent;
            this.cbbCategory.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.cbbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbCategory.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbbCategory.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbbCategory.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cbbCategory.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.cbbCategory.ItemHeight = 30;
            this.cbbCategory.Location = new System.Drawing.Point(15, 491);
            this.cbbCategory.Name = "cbbCategory";
            this.cbbCategory.Size = new System.Drawing.Size(296, 36);
            this.cbbCategory.TabIndex = 4;
            this.cbbCategory.Click += new System.EventHandler(this.cbbCategory_Click);
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.BorderRadius = 25;
            this.guna2Panel1.Controls.Add(this.panelLb);
            this.guna2Panel1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(55)))));
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.Size = new System.Drawing.Size(314, 186);
            this.guna2Panel1.TabIndex = 3;
            // 
            // panelLb
            // 
            this.panelLb.BackColor = System.Drawing.Color.Transparent;
            this.panelLb.Font = new System.Drawing.Font("Segoe Script", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelLb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(72)))), ((int)(((byte)(153)))));
            this.panelLb.Location = new System.Drawing.Point(45, 55);
            this.panelLb.Margin = new System.Windows.Forms.Padding(4);
            this.panelLb.Name = "panelLb";
            this.panelLb.Size = new System.Drawing.Size(227, 73);
            this.panelLb.TabIndex = 18;
            this.panelLb.Text = "Add Book";
            // 
            // saveBookBtn
            // 
            this.saveBookBtn.BorderRadius = 20;
            this.saveBookBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.saveBookBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.saveBookBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.saveBookBtn.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.saveBookBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.saveBookBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(55)))));
            this.saveBookBtn.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(55)))));
            this.saveBookBtn.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveBookBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(72)))), ((int)(((byte)(153)))));
            this.saveBookBtn.Location = new System.Drawing.Point(39, 645);
            this.saveBookBtn.Name = "saveBookBtn";
            this.saveBookBtn.Size = new System.Drawing.Size(240, 45);
            this.saveBookBtn.TabIndex = 2;
            this.saveBookBtn.Text = "Save";
            this.saveBookBtn.Click += new System.EventHandler(this.saveBookBtn_Click);
            // 
            // yearTxt
            // 
            this.yearTxt.BorderColor = System.Drawing.Color.White;
            this.yearTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.yearTxt.DefaultText = "";
            this.yearTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.yearTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.yearTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.yearTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.yearTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.yearTxt.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.yearTxt.ForeColor = System.Drawing.Color.Black;
            this.yearTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.yearTxt.Location = new System.Drawing.Point(3, 555);
            this.yearTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.yearTxt.Name = "yearTxt";
            this.yearTxt.PasswordChar = '\0';
            this.yearTxt.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            this.yearTxt.PlaceholderText = "Publish Year";
            this.yearTxt.SelectedText = "";
            this.yearTxt.Size = new System.Drawing.Size(308, 48);
            this.yearTxt.TabIndex = 0;
            this.yearTxt.TextOffset = new System.Drawing.Point(10, 0);
            this.yearTxt.Click += new System.EventHandler(this.yearTxt_Click);
            // 
            // authorTxt
            // 
            this.authorTxt.BorderColor = System.Drawing.Color.White;
            this.authorTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.authorTxt.DefaultText = "";
            this.authorTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.authorTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.authorTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.authorTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.authorTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.authorTxt.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.authorTxt.ForeColor = System.Drawing.Color.Black;
            this.authorTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.authorTxt.Location = new System.Drawing.Point(3, 401);
            this.authorTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.authorTxt.Name = "authorTxt";
            this.authorTxt.PasswordChar = '\0';
            this.authorTxt.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            this.authorTxt.PlaceholderText = "Author";
            this.authorTxt.SelectedText = "";
            this.authorTxt.Size = new System.Drawing.Size(308, 48);
            this.authorTxt.TabIndex = 0;
            this.authorTxt.TextOffset = new System.Drawing.Point(10, 0);
            this.authorTxt.TextChanged += new System.EventHandler(this.authorTxt_TextChanged);
            // 
            // quantityTxt
            // 
            this.quantityTxt.BorderColor = System.Drawing.Color.White;
            this.quantityTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.quantityTxt.DefaultText = "";
            this.quantityTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.quantityTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.quantityTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.quantityTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.quantityTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.quantityTxt.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.quantityTxt.ForeColor = System.Drawing.Color.Black;
            this.quantityTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.quantityTxt.Location = new System.Drawing.Point(3, 250);
            this.quantityTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.quantityTxt.Name = "quantityTxt";
            this.quantityTxt.PasswordChar = '\0';
            this.quantityTxt.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            this.quantityTxt.PlaceholderText = "Quantity";
            this.quantityTxt.SelectedText = "";
            this.quantityTxt.Size = new System.Drawing.Size(308, 48);
            this.quantityTxt.TabIndex = 0;
            this.quantityTxt.TextOffset = new System.Drawing.Point(10, 0);
            this.quantityTxt.Click += new System.EventHandler(this.quantityTxt_Click);
            // 
            // titleTxt
            // 
            this.titleTxt.BorderColor = System.Drawing.Color.White;
            this.titleTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.titleTxt.DefaultText = "";
            this.titleTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.titleTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.titleTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.titleTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.titleTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.titleTxt.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.titleTxt.ForeColor = System.Drawing.Color.Black;
            this.titleTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.titleTxt.Location = new System.Drawing.Point(3, 324);
            this.titleTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.titleTxt.Name = "titleTxt";
            this.titleTxt.PasswordChar = '\0';
            this.titleTxt.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            this.titleTxt.PlaceholderText = "Title";
            this.titleTxt.SelectedText = "";
            this.titleTxt.Size = new System.Drawing.Size(308, 48);
            this.titleTxt.TabIndex = 0;
            this.titleTxt.TextOffset = new System.Drawing.Point(10, 0);
            this.titleTxt.Click += new System.EventHandler(this.titleTxt_Click);
            // 
            // addcategorypanel
            // 
            this.addcategorypanel.BackColor = System.Drawing.Color.Transparent;
            this.addcategorypanel.BorderColor = System.Drawing.Color.White;
            this.addcategorypanel.BorderRadius = 25;
            this.addcategorypanel.Controls.Add(this.guna2Panel4);
            this.addcategorypanel.Controls.Add(this.categoryLocationError);
            this.addcategorypanel.Controls.Add(this.SaveCategoryBtn);
            this.addcategorypanel.Controls.Add(this.categoryDayError);
            this.addcategorypanel.Controls.Add(this.categoryNumberdayTxt);
            this.addcategorypanel.Controls.Add(this.categoryNameError);
            this.addcategorypanel.Controls.Add(this.categoryLocationTxt);
            this.addcategorypanel.Controls.Add(this.categoryNameTxt);
            this.addcategorypanel.FillColor = System.Drawing.Color.White;
            this.addcategorypanel.Location = new System.Drawing.Point(1245, 4);
            this.addcategorypanel.Margin = new System.Windows.Forms.Padding(4);
            this.addcategorypanel.Name = "addcategorypanel";
            this.addcategorypanel.Size = new System.Drawing.Size(314, 698);
            this.addcategorypanel.TabIndex = 19;
            // 
            // guna2Panel4
            // 
            this.guna2Panel4.BorderRadius = 25;
            this.guna2Panel4.Controls.Add(this.guna2HtmlLabel4);
            this.guna2Panel4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(55)))));
            this.guna2Panel4.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel4.Name = "guna2Panel4";
            this.guna2Panel4.Size = new System.Drawing.Size(314, 186);
            this.guna2Panel4.TabIndex = 3;
            // 
            // guna2HtmlLabel4
            // 
            this.guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel4.Font = new System.Drawing.Font("Segoe Script", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(72)))), ((int)(((byte)(153)))));
            this.guna2HtmlLabel4.Location = new System.Drawing.Point(4, 55);
            this.guna2HtmlLabel4.Margin = new System.Windows.Forms.Padding(4);
            this.guna2HtmlLabel4.Name = "guna2HtmlLabel4";
            this.guna2HtmlLabel4.Size = new System.Drawing.Size(310, 73);
            this.guna2HtmlLabel4.TabIndex = 18;
            this.guna2HtmlLabel4.Text = "Add Category";
            // 
            // categoryLocationError
            // 
            this.categoryLocationError.BackColor = System.Drawing.Color.Transparent;
            this.categoryLocationError.ForeColor = System.Drawing.Color.Red;
            this.categoryLocationError.Location = new System.Drawing.Point(187, 533);
            this.categoryLocationError.Name = "categoryLocationError";
            this.categoryLocationError.Size = new System.Drawing.Size(91, 18);
            this.categoryLocationError.TabIndex = 6;
            this.categoryLocationError.Text = "Fill information!";
            this.categoryLocationError.Visible = false;
            // 
            // SaveCategoryBtn
            // 
            this.SaveCategoryBtn.BorderRadius = 20;
            this.SaveCategoryBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.SaveCategoryBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.SaveCategoryBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.SaveCategoryBtn.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.SaveCategoryBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.SaveCategoryBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(55)))));
            this.SaveCategoryBtn.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(41)))), ((int)(((byte)(55)))));
            this.SaveCategoryBtn.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveCategoryBtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(72)))), ((int)(((byte)(153)))));
            this.SaveCategoryBtn.Location = new System.Drawing.Point(38, 610);
            this.SaveCategoryBtn.Name = "SaveCategoryBtn";
            this.SaveCategoryBtn.Size = new System.Drawing.Size(240, 45);
            this.SaveCategoryBtn.TabIndex = 2;
            this.SaveCategoryBtn.Text = "Save";
            this.SaveCategoryBtn.Click += new System.EventHandler(this.SaveCategoryBtn_Click);
            // 
            // categoryDayError
            // 
            this.categoryDayError.BackColor = System.Drawing.Color.Transparent;
            this.categoryDayError.ForeColor = System.Drawing.Color.Red;
            this.categoryDayError.Location = new System.Drawing.Point(187, 453);
            this.categoryDayError.Name = "categoryDayError";
            this.categoryDayError.Size = new System.Drawing.Size(91, 18);
            this.categoryDayError.TabIndex = 6;
            this.categoryDayError.Text = "Fill information!";
            this.categoryDayError.Visible = false;
            // 
            // categoryNumberdayTxt
            // 
            this.categoryNumberdayTxt.BorderColor = System.Drawing.Color.White;
            this.categoryNumberdayTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.categoryNumberdayTxt.DefaultText = "";
            this.categoryNumberdayTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.categoryNumberdayTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.categoryNumberdayTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.categoryNumberdayTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.categoryNumberdayTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.categoryNumberdayTxt.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.categoryNumberdayTxt.ForeColor = System.Drawing.Color.Black;
            this.categoryNumberdayTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.categoryNumberdayTxt.Location = new System.Drawing.Point(3, 401);
            this.categoryNumberdayTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.categoryNumberdayTxt.Name = "categoryNumberdayTxt";
            this.categoryNumberdayTxt.PasswordChar = '\0';
            this.categoryNumberdayTxt.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            this.categoryNumberdayTxt.PlaceholderText = "Lend_Number_Day";
            this.categoryNumberdayTxt.SelectedText = "";
            this.categoryNumberdayTxt.Size = new System.Drawing.Size(308, 48);
            this.categoryNumberdayTxt.TabIndex = 0;
            this.categoryNumberdayTxt.TextOffset = new System.Drawing.Point(10, 0);
            this.categoryNumberdayTxt.Click += new System.EventHandler(this.categoryNumberdayTxt_Click);
            // 
            // categoryNameError
            // 
            this.categoryNameError.BackColor = System.Drawing.Color.Transparent;
            this.categoryNameError.ForeColor = System.Drawing.Color.Red;
            this.categoryNameError.Location = new System.Drawing.Point(187, 376);
            this.categoryNameError.Name = "categoryNameError";
            this.categoryNameError.Size = new System.Drawing.Size(91, 18);
            this.categoryNameError.TabIndex = 6;
            this.categoryNameError.Text = "Fill information!";
            this.categoryNameError.Visible = false;
            // 
            // categoryLocationTxt
            // 
            this.categoryLocationTxt.BorderColor = System.Drawing.Color.White;
            this.categoryLocationTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.categoryLocationTxt.DefaultText = "";
            this.categoryLocationTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.categoryLocationTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.categoryLocationTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.categoryLocationTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.categoryLocationTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.categoryLocationTxt.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.categoryLocationTxt.ForeColor = System.Drawing.Color.Black;
            this.categoryLocationTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.categoryLocationTxt.Location = new System.Drawing.Point(3, 478);
            this.categoryLocationTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.categoryLocationTxt.Name = "categoryLocationTxt";
            this.categoryLocationTxt.PasswordChar = '\0';
            this.categoryLocationTxt.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            this.categoryLocationTxt.PlaceholderText = "Location";
            this.categoryLocationTxt.SelectedText = "";
            this.categoryLocationTxt.Size = new System.Drawing.Size(308, 48);
            this.categoryLocationTxt.TabIndex = 0;
            this.categoryLocationTxt.TextOffset = new System.Drawing.Point(10, 0);
            this.categoryLocationTxt.Click += new System.EventHandler(this.categoryLocationTxt_Click);
            // 
            // categoryNameTxt
            // 
            this.categoryNameTxt.BorderColor = System.Drawing.Color.White;
            this.categoryNameTxt.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.categoryNameTxt.DefaultText = "";
            this.categoryNameTxt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.categoryNameTxt.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.categoryNameTxt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.categoryNameTxt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.categoryNameTxt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.categoryNameTxt.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.categoryNameTxt.ForeColor = System.Drawing.Color.Black;
            this.categoryNameTxt.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.categoryNameTxt.Location = new System.Drawing.Point(3, 324);
            this.categoryNameTxt.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.categoryNameTxt.Name = "categoryNameTxt";
            this.categoryNameTxt.PasswordChar = '\0';
            this.categoryNameTxt.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(107)))), ((int)(((byte)(114)))), ((int)(((byte)(128)))));
            this.categoryNameTxt.PlaceholderText = "Name";
            this.categoryNameTxt.SelectedText = "";
            this.categoryNameTxt.Size = new System.Drawing.Size(308, 48);
            this.categoryNameTxt.TabIndex = 0;
            this.categoryNameTxt.TextOffset = new System.Drawing.Point(10, 0);
            this.categoryNameTxt.Click += new System.EventHandler(this.categoryNameTxt_Click);
            // 
            // addCategory
            // 
            this.addCategory.BorderRadius = 10;
            this.addCategory.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.addCategory.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.addCategory.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.addCategory.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.addCategory.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            this.addCategory.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addCategory.ForeColor = System.Drawing.Color.White;
            this.addCategory.Location = new System.Drawing.Point(188, 50);
            this.addCategory.Margin = new System.Windows.Forms.Padding(4);
            this.addCategory.Name = "addCategory";
            this.addCategory.Size = new System.Drawing.Size(133, 46);
            this.addCategory.TabIndex = 19;
            this.addCategory.Text = "Add Category";
            this.addCategory.Click += new System.EventHandler(this.addCategory_Click);
            // 
            // addBtn
            // 
            this.addBtn.BorderRadius = 10;
            this.addBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.addBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.addBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.addBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.addBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            this.addBtn.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addBtn.ForeColor = System.Drawing.Color.White;
            this.addBtn.Location = new System.Drawing.Point(23, 50);
            this.addBtn.Margin = new System.Windows.Forms.Padding(4);
            this.addBtn.Name = "addBtn";
            this.addBtn.Size = new System.Drawing.Size(133, 46);
            this.addBtn.TabIndex = 17;
            this.addBtn.Text = "Add Book";
            this.addBtn.Click += new System.EventHandler(this.addBtn_Click);
            // 
            // catalogPanel
            // 
            this.catalogPanel.BorderRadius = 25;
            this.catalogPanel.Controls.Add(this.catalogDGV);
            this.catalogPanel.Controls.Add(this.updateBtn);
            this.catalogPanel.Controls.Add(this.deleteBtn);
            this.catalogPanel.Controls.Add(this.guna2HtmlLabel13);
            this.catalogPanel.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            this.catalogPanel.Location = new System.Drawing.Point(23, 110);
            this.catalogPanel.Margin = new System.Windows.Forms.Padding(4);
            this.catalogPanel.Name = "catalogPanel";
            this.catalogPanel.Size = new System.Drawing.Size(1510, 595);
            this.catalogPanel.TabIndex = 15;
            // 
            // catalogDGV
            // 
            this.catalogDGV.AllowUserToResizeColumns = false;
            this.catalogDGV.AllowUserToResizeRows = false;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle46.BackColor = System.Drawing.SystemColors.GrayText;
            dataGridViewCellStyle46.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.catalogDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle46;
            this.catalogDGV.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            this.catalogDGV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle47.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle47.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(88)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle47.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            dataGridViewCellStyle47.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle47.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(88)))), ((int)(((byte)(103)))));
            dataGridViewCellStyle47.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.catalogDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle47;
            this.catalogDGV.ColumnHeadersHeight = 40;
            dataGridViewCellStyle48.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle48.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle48.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle48.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle48.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            dataGridViewCellStyle48.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle48.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle48.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.catalogDGV.DefaultCellStyle = dataGridViewCellStyle48;
            this.catalogDGV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.catalogDGV.Location = new System.Drawing.Point(33, 80);
            this.catalogDGV.Name = "catalogDGV";
            this.catalogDGV.ReadOnly = true;
            this.catalogDGV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle49.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle49.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle49.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle49.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            dataGridViewCellStyle49.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            dataGridViewCellStyle49.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle49.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.catalogDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle49;
            this.catalogDGV.RowHeadersVisible = false;
            this.catalogDGV.RowHeadersWidth = 51;
            this.catalogDGV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle50.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle50.BackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle50.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle50.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            dataGridViewCellStyle50.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle50.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle50.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.catalogDGV.RowsDefaultCellStyle = dataGridViewCellStyle50;
            this.catalogDGV.RowTemplate.Height = 30;
            this.catalogDGV.Size = new System.Drawing.Size(1445, 453);
            this.catalogDGV.TabIndex = 24;
            this.catalogDGV.TabStop = false;
            this.catalogDGV.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.Transparent;
            this.catalogDGV.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.catalogDGV.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.catalogDGV.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.catalogDGV.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.catalogDGV.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            this.catalogDGV.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.catalogDGV.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            this.catalogDGV.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.catalogDGV.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.catalogDGV.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Gainsboro;
            this.catalogDGV.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.catalogDGV.ThemeStyle.HeaderStyle.Height = 40;
            this.catalogDGV.ThemeStyle.ReadOnly = true;
            this.catalogDGV.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(76)))), ((int)(((byte)(73)))), ((int)(((byte)(72)))));
            this.catalogDGV.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.catalogDGV.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.catalogDGV.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Gainsboro;
            this.catalogDGV.ThemeStyle.RowsStyle.Height = 30;
            this.catalogDGV.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.catalogDGV.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            // 
            // updateBtn
            // 
            this.updateBtn.BorderRadius = 10;
            this.updateBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.updateBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.updateBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.updateBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.updateBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.updateBtn.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateBtn.ForeColor = System.Drawing.Color.Black;
            this.updateBtn.Location = new System.Drawing.Point(1191, 10);
            this.updateBtn.Margin = new System.Windows.Forms.Padding(4);
            this.updateBtn.Name = "updateBtn";
            this.updateBtn.Size = new System.Drawing.Size(133, 46);
            this.updateBtn.TabIndex = 18;
            this.updateBtn.Text = "Update";
            this.updateBtn.Click += new System.EventHandler(this.updateBtn_Click);
            // 
            // deleteBtn
            // 
            this.deleteBtn.BorderRadius = 10;
            this.deleteBtn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.deleteBtn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.deleteBtn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.deleteBtn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.deleteBtn.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.deleteBtn.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deleteBtn.ForeColor = System.Drawing.Color.Black;
            this.deleteBtn.Location = new System.Drawing.Point(1348, 10);
            this.deleteBtn.Margin = new System.Windows.Forms.Padding(4);
            this.deleteBtn.Name = "deleteBtn";
            this.deleteBtn.Size = new System.Drawing.Size(133, 46);
            this.deleteBtn.TabIndex = 18;
            this.deleteBtn.Text = "Delete";
            this.deleteBtn.Click += new System.EventHandler(this.deleteBtn_Click);
            // 
            // guna2HtmlLabel13
            // 
            this.guna2HtmlLabel13.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel13.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.guna2HtmlLabel13.Location = new System.Drawing.Point(29, 10);
            this.guna2HtmlLabel13.Margin = new System.Windows.Forms.Padding(4);
            this.guna2HtmlLabel13.Name = "guna2HtmlLabel13";
            this.guna2HtmlLabel13.Size = new System.Drawing.Size(166, 39);
            this.guna2HtmlLabel13.TabIndex = 16;
            this.guna2HtmlLabel13.Text = "Book Catalog";
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(88)))), ((int)(((byte)(103)))));
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(23, 10);
            this.guna2HtmlLabel2.Margin = new System.Windows.Forms.Padding(4);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(239, 39);
            this.guna2HtmlLabel2.TabIndex = 0;
            this.guna2HtmlLabel2.Text = "Book Management";
            // 
            // authorError
            // 
            this.authorError.BackColor = System.Drawing.Color.Transparent;
            this.authorError.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.authorError.ForeColor = System.Drawing.Color.Red;
            this.authorError.Location = new System.Drawing.Point(173, 456);
            this.authorError.Name = "authorError";
            this.authorError.Size = new System.Drawing.Size(123, 15);
            this.authorError.TabIndex = 1;
            this.authorError.Text = "Please fill this information!";
            this.authorError.Visible = false;
            // 
            // tiltleError
            // 
            this.tiltleError.BackColor = System.Drawing.Color.Transparent;
            this.tiltleError.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tiltleError.ForeColor = System.Drawing.Color.Red;
            this.tiltleError.Location = new System.Drawing.Point(173, 379);
            this.tiltleError.Name = "tiltleError";
            this.tiltleError.Size = new System.Drawing.Size(123, 15);
            this.tiltleError.TabIndex = 1;
            this.tiltleError.Text = "Please fill this information!";
            this.tiltleError.Visible = false;
            // 
            // yearError
            // 
            this.yearError.BackColor = System.Drawing.Color.Transparent;
            this.yearError.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearError.ForeColor = System.Drawing.Color.Red;
            this.yearError.Location = new System.Drawing.Point(173, 610);
            this.yearError.Name = "yearError";
            this.yearError.Size = new System.Drawing.Size(123, 15);
            this.yearError.TabIndex = 1;
            this.yearError.Text = "Please fill this information!";
            this.yearError.Visible = false;
            // 
            // namecategoryerror
            // 
            this.namecategoryerror.BackColor = System.Drawing.Color.Transparent;
            this.namecategoryerror.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namecategoryerror.ForeColor = System.Drawing.Color.Red;
            this.namecategoryerror.Location = new System.Drawing.Point(176, 379);
            this.namecategoryerror.Name = "namecategoryerror";
            this.namecategoryerror.Size = new System.Drawing.Size(123, 15);
            this.namecategoryerror.TabIndex = 5;
            this.namecategoryerror.Text = "Please fill this information!";
            this.namecategoryerror.Visible = false;
            // 
            // locationerror
            // 
            this.locationerror.BackColor = System.Drawing.Color.Transparent;
            this.locationerror.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locationerror.ForeColor = System.Drawing.Color.Red;
            this.locationerror.Location = new System.Drawing.Point(176, 533);
            this.locationerror.Name = "locationerror";
            this.locationerror.Size = new System.Drawing.Size(123, 15);
            this.locationerror.TabIndex = 7;
            this.locationerror.Text = "Please fill this information!";
            this.locationerror.Visible = false;
            // 
            // idError
            // 
            this.idError.BackColor = System.Drawing.Color.Transparent;
            this.idError.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idError.ForeColor = System.Drawing.Color.Red;
            this.idError.Location = new System.Drawing.Point(173, 302);
            this.idError.Name = "idError";
            this.idError.Size = new System.Drawing.Size(123, 15);
            this.idError.TabIndex = 1;
            this.idError.Text = "Please fill this information!";
            this.idError.Visible = false;
            // 
            // categoryError
            // 
            this.categoryError.BackColor = System.Drawing.Color.Transparent;
            this.categoryError.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categoryError.ForeColor = System.Drawing.Color.Red;
            this.categoryError.Location = new System.Drawing.Point(173, 533);
            this.categoryError.Name = "categoryError";
            this.categoryError.Size = new System.Drawing.Size(123, 15);
            this.categoryError.TabIndex = 1;
            this.categoryError.Text = "Please fill this information!";
            this.categoryError.Visible = false;
            // 
            // numberdayerror
            // 
            this.numberdayerror.BackColor = System.Drawing.Color.Transparent;
            this.numberdayerror.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberdayerror.ForeColor = System.Drawing.Color.Red;
            this.numberdayerror.Location = new System.Drawing.Point(176, 452);
            this.numberdayerror.Name = "numberdayerror";
            this.numberdayerror.Size = new System.Drawing.Size(123, 15);
            this.numberdayerror.TabIndex = 6;
            this.numberdayerror.Text = "Please fill this information!";
            this.numberdayerror.Visible = false;
            // 
            // BookManagementForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(53)))), ((int)(((byte)(51)))), ((int)(((byte)(52)))));
            this.ClientSize = new System.Drawing.Size(1560, 737);
            this.Controls.Add(this.mainPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Location = new System.Drawing.Point(215, 187);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "BookManagementForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "MainForm";
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            this.deletePanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.deleteDGV)).EndInit();
            this.guna2Panel3.ResumeLayout(false);
            this.guna2Panel3.PerformLayout();
            this.addPanel.ResumeLayout(false);
            this.addPanel.PerformLayout();
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel1.PerformLayout();
            this.addcategorypanel.ResumeLayout(false);
            this.addcategorypanel.PerformLayout();
            this.guna2Panel4.ResumeLayout(false);
            this.guna2Panel4.PerformLayout();
            this.catalogPanel.ResumeLayout(false);
            this.catalogPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.catalogDGV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel IDcategoryerror;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel7;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel8;
        private Guna.UI2.WinForms.Guna2Button guna2Button5;
        private Guna.UI2.WinForms.Guna2TextBox searchTxt;
        private Guna.UI2.WinForms.Guna2ComboBox listSearchCb;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel mainPanel;
        private Guna.UI2.WinForms.Guna2Panel deletePanel;
        private Guna.UI2.WinForms.Guna2DataGridView deleteDGV;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel11;
        private Guna.UI2.WinForms.Guna2GradientButton deleteBarBtn;
        private Guna.UI2.WinForms.Guna2Panel addPanel;
        private Guna.UI2.WinForms.Guna2HtmlLabel bookYearError;
        private Guna.UI2.WinForms.Guna2HtmlLabel bookCategoryError;
        private Guna.UI2.WinForms.Guna2HtmlLabel bookAuthorError;
        private Guna.UI2.WinForms.Guna2HtmlLabel quantityError;
        private Guna.UI2.WinForms.Guna2HtmlLabel bookTiltleError;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2ComboBox cbbCategory;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel panelLb;
        private Guna.UI2.WinForms.Guna2GradientButton saveBookBtn;
        private Guna.UI2.WinForms.Guna2TextBox yearTxt;
        private Guna.UI2.WinForms.Guna2TextBox authorTxt;
        private Guna.UI2.WinForms.Guna2TextBox quantityTxt;
        private Guna.UI2.WinForms.Guna2TextBox titleTxt;
        private Guna.UI2.WinForms.Guna2Panel addcategorypanel;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel categoryLocationError;
        private Guna.UI2.WinForms.Guna2GradientButton SaveCategoryBtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel categoryDayError;
        private Guna.UI2.WinForms.Guna2TextBox categoryNumberdayTxt;
        private Guna.UI2.WinForms.Guna2HtmlLabel categoryNameError;
        private Guna.UI2.WinForms.Guna2TextBox categoryLocationTxt;
        private Guna.UI2.WinForms.Guna2TextBox categoryNameTxt;
        private Guna.UI2.WinForms.Guna2Button addCategory;
        private Guna.UI2.WinForms.Guna2Button addBtn;
        private Guna.UI2.WinForms.Guna2Panel catalogPanel;
        private Guna.UI2.WinForms.Guna2DataGridView catalogDGV;
        private Guna.UI2.WinForms.Guna2Button updateBtn;
        private Guna.UI2.WinForms.Guna2Button deleteBtn;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel13;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel authorError;
        private Guna.UI2.WinForms.Guna2HtmlLabel tiltleError;
        private Guna.UI2.WinForms.Guna2HtmlLabel yearError;
        private Guna.UI2.WinForms.Guna2HtmlLabel namecategoryerror;
        private Guna.UI2.WinForms.Guna2HtmlLabel locationerror;
        private Guna.UI2.WinForms.Guna2HtmlLabel idError;
        private Guna.UI2.WinForms.Guna2HtmlLabel categoryError;
        private Guna.UI2.WinForms.Guna2HtmlLabel numberdayerror;
    }
}