﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL_3.DTO
{
    public class BookDelete
    {
        public int id { get; set; }
        public bool borrowable { get; set; }
    }
}
