﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL_3.DTO
{
    public class ImagineChart
    {
        public DateTime date { get; set; }
        public int quantity { get; set; }
    }
}
