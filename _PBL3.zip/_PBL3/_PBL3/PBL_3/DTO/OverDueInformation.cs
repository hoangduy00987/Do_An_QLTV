﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PBL_3.DTO
{
    public class OverDueInformation
    {
        public string Book { get; set; }
        public int Day { get; set; }

    }
}